'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const tls = require('tls');
const { ProxyPool, createProxyAgent, connectSocks5Socket, connectSocks4Socket } = require('./proxy');

const WEB_SOURCES = [
  // Fast SOCKS5 Sources (highest throughput and TLS stability)
  { name: 'ProxyScrape-SOCKS5', url: 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=2000&country=all', protocol: 'socks5' },
  { name: 'ProxyScrape-v4-SOCKS5', url: 'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&protocol=socks5&timeout=2000', protocol: 'socks5' },
  { name: 'Monosans-SOCKS5', url: 'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt', protocol: 'socks5' },
  { name: 'TheSpeedX-SOCKS5', url: 'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt', protocol: 'socks5' },
  { name: 'Zevtyardt-SOCKS5', url: 'https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks5.txt', protocol: 'socks5' },
  { name: 'MuRongPIG-SOCKS5', url: 'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt', protocol: 'socks5' },
  { name: 'Hookzof-SOCKS5', url: 'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt', protocol: 'socks5' },

  // SOCKS4 Sources
  { name: 'ProxyScrape-SOCKS4', url: 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=2000&country=all', protocol: 'socks4' },
  { name: 'Monosans-SOCKS4', url: 'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt', protocol: 'socks4' },
  { name: 'TheSpeedX-SOCKS4', url: 'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt', protocol: 'socks4' },

  // Elite HTTP / HTTPS Sources
  { name: 'ProxyScrape-HTTP', url: 'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=2000&country=all&ssl=all&anonymity=elite', protocol: 'http' },
  { name: 'ProxyScrape-v4-HTTP', url: 'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&anonymity=elite&timeout=2000', protocol: 'http' },
  { name: 'Monosans-HTTP', url: 'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt', protocol: 'http' },
  { name: 'TheSpeedX-HTTP', url: 'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt', protocol: 'http' },
  { name: 'Geonode-API', url: 'https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc', protocol: 'auto' },
  { name: 'SSLProxies', url: 'https://www.sslproxies.org/', protocol: 'http' },
  { name: 'USProxy', url: 'https://www.us-proxy.org/', protocol: 'http' },
];

const CACHE_FILE = path.resolve(__dirname, '../outputs/verified_mailtm_proxies.json');
const CACHE_TTL_MS = 20 * 60 * 1000; // 20 minutes

/**
 * Validates whether an HTTP, SOCKS5, or SOCKS4 proxy can reliably tunnel to api.mail.tm
 * and complete a TLS handshake + HTTP GET request with latency <= maxLatencyMs.
 */
function validateMailtmProxy(hostOrProxy, port, authOrLatency = 2000, maybeMaxLatency = 2000) {
  return new Promise(async (resolve) => {
    let host, portNum, protocol = 'http', auth = null, maxLatencyMs = 2000;
    let proxyObj = null;

    if (typeof hostOrProxy === 'object' && hostOrProxy !== null) {
      proxyObj = hostOrProxy;
      host = proxyObj.host;
      portNum = parseInt(proxyObj.port, 10);
      protocol = proxyObj.protocol || 'http';
      auth = proxyObj.auth || (proxyObj.username && proxyObj.password ? `${proxyObj.username}:${proxyObj.password}` : null);
      maxLatencyMs = typeof port === 'number' ? port : (typeof authOrLatency === 'number' ? authOrLatency : 2000);
    } else {
      host = hostOrProxy;
      portNum = parseInt(port, 10);
      if (typeof authOrLatency === 'string') {
        auth = authOrLatency;
        maxLatencyMs = typeof maybeMaxLatency === 'number' ? maybeMaxLatency : 2000;
      } else if (typeof authOrLatency === 'number') {
        maxLatencyMs = authOrLatency;
      }
    }

    const t0 = Date.now();
    let sock = null;
    let done = false;

    const finish = (result) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (sock) try { sock.destroy(); } catch {}
      resolve(result);
    };

    const timer = setTimeout(() => finish(null), maxLatencyMs);

    try {
      if (protocol === 'socks5') {
        const [u, p] = auth ? auth.split(':') : [proxyObj?.username, proxyObj?.password];
        sock = await connectSocks5Socket({
          host,
          port: portNum,
          targetHost: 'api.mail.tm',
          targetPort: 443,
          username: u,
          password: p,
          timeoutMs: maxLatencyMs,
        });
      } else if (protocol === 'socks4') {
        sock = await connectSocks4Socket({
          host,
          port: portNum,
          targetHost: 'api.mail.tm',
          targetPort: 443,
          username: auth ? auth.split(':')[0] : (proxyObj?.username || ''),
          timeoutMs: maxLatencyMs,
        });
      } else {
        // HTTP CONNECT tunnel
        sock = await new Promise((res, rej) => {
          const headers = { Host: 'api.mail.tm:443' };
          if (auth) {
            headers['Proxy-Authorization'] = 'Basic ' + Buffer.from(auth).toString('base64');
          }
          const req = http.request({
            host,
            port: portNum,
            method: 'CONNECT',
            path: 'api.mail.tm:443',
            headers,
            timeout: maxLatencyMs,
          });
          req.on('connect', (r, s) => {
            if (r.statusCode === 200) res(s);
            else { s.destroy(); rej(new Error('CONNECT status ' + r.statusCode)); }
          });
          req.on('error', rej);
          req.on('timeout', () => { req.destroy(); rej(new Error('timeout')); });
          req.end();
        });
      }

      const tlsSocket = tls.connect(
        { socket: sock, servername: 'api.mail.tm', rejectUnauthorized: false },
        () => {
          tlsSocket.write(
            'GET /domains HTTP/1.1\r\nHost: api.mail.tm\r\nConnection: close\r\nAccept: application/json\r\n\r\n'
          );
        }
      );

      let data = '';
      tlsSocket.on('data', (c) => (data += c));
      tlsSocket.on('end', () => {
        const latency = Date.now() - t0;
        if (
          latency <= maxLatencyMs &&
          data.includes('200 OK') &&
          (data.includes('maxxspace.com') || data.includes('hydra:member') || data.includes('@mail.tm') || data.includes('"domain"'))
        ) {
          finish({
            host,
            port: portNum,
            protocol,
            latency,
            raw: `${protocol}://${auth ? auth + '@' : ''}${host}:${portNum}`,
            username: proxyObj?.username || (auth ? auth.split(':')[0] : null),
            password: proxyObj?.password || (auth ? auth.split(':')[1] : null),
            ignoreCertErrors: true,
          });
        } else {
          finish(null);
        }
      });
      tlsSocket.on('error', () => finish(null));
    } catch {
      finish(null);
    }
  });
}

/**
 * Scrapes fresh candidate proxies from high-quality web sources across SOCKS5, SOCKS4, and HTTP.
 */
async function scrapeCandidates({ maxCandidates = 2500, log = () => {} } = {}) {
  const candidateMap = new Map();

  await Promise.allSettled(
    WEB_SOURCES.map(async (source) => {
      try {
        const res = await fetch(source.url, {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          },
          signal: AbortSignal.timeout(6000),
        });
        if (!res.ok) return;
        const text = await res.text();

        // Standard IP:Port matching
        const ipPortMatches = text.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5}\b/g) || [];
        for (const m of ipPortMatches) {
          const [host, portStr] = m.split(':');
          const port = parseInt(portStr, 10);
          if (port > 0 && port <= 65535) {
            const key = `${host}:${port}`;
            // If already present, prefer SOCKS5 protocol designation
            if (!candidateMap.has(key) || source.protocol === 'socks5') {
              candidateMap.set(key, { host, port, protocol: source.protocol || 'http' });
            }
          }
        }

        // HTML tables (free-proxy-list, sslproxies, us-proxy)
        const tableMatches = text.matchAll(/<tr>\s*<td>(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})<\/td>\s*<td>(\d{2,5})<\/td>/g);
        for (const tm of tableMatches) {
          const host = tm[1];
          const port = parseInt(tm[2], 10);
          const key = `${host}:${port}`;
          if (!candidateMap.has(key)) {
            candidateMap.set(key, { host, port, protocol: source.protocol || 'http' });
          }
        }

        // JSON APIs (e.g. Geonode)
        try {
          const j = JSON.parse(text);
          if (j.data && Array.isArray(j.data)) {
            for (const item of j.data) {
              if (item.ip && item.port) {
                const host = item.ip;
                const port = parseInt(item.port, 10);
                const proto = Array.isArray(item.protocols) && item.protocols.includes('socks5')
                  ? 'socks5'
                  : (Array.isArray(item.protocols) && item.protocols.includes('socks4') ? 'socks4' : 'http');
                candidateMap.set(`${host}:${port}`, { host, port, protocol: proto });
              }
            }
          }
        } catch {}
      } catch {
        /* ignore individual source timeout */
      }
    })
  );

  return Array.from(candidateMap.values()).slice(0, maxCandidates);
}

/**
 * Scrapes proxies from web sources and tests them concurrently
 * against api.mail.tm until a verified pool of < maxLatencyMs proxies is formed.
 */
async function scrapeAndVerifyMailtmProxies({
  targetCount = 10,
  maxLatency = 2000,
  maxCandidates = 2500,
  forceRefresh = false,
  log = () => {},
} = {}) {
  // Check local cache first
  if (!forceRefresh && fs.existsSync(CACHE_FILE)) {
    try {
      const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
      if (
        Date.now() - cached.timestamp < CACHE_TTL_MS &&
        Array.isArray(cached.proxies) &&
        cached.proxies.length >= targetCount
      ) {
        const fast = cached.proxies.filter((p) => p.latency <= maxLatency);
        if (fast.length >= targetCount) {
          log(
            `using ${fast.length} cached verified mail.tm proxies (lowest latency: ${fast[0].latency}ms, age: ${Math.round((Date.now() - cached.timestamp) / 60000)}m)`
          );
          return fast;
        }
      }
    } catch {
      /* ignore cache read error */
    }
  }

  log(`scraping fresh proxies (SOCKS5, SOCKS4, HTTP) from web sources (filtering max latency < ${maxLatency}ms)...`);
  const candidateList = await scrapeCandidates({ maxCandidates: Math.max(maxCandidates, 2000), log });
  log(`probing up to ${candidateList.length} unique candidates against api.mail.tm (${maxLatency}ms cutoff)...`);

  const verified = [];
  const chunkSize = 200;
  for (let i = 0; i < candidateList.length && verified.length < targetCount; i += chunkSize) {
    const chunk = candidateList.slice(i, i + chunkSize);
    await Promise.all(
      chunk.map(async (candidate) => {
        const r = await validateMailtmProxy(candidate, maxLatency);
        if (r && verified.length < targetCount) {
          verified.push(r);
          log(`✔ verified fast (<${maxLatency}ms · ${r.protocol}): ${r.host}:${r.port} (${r.latency}ms)`);
        }
      })
    );
  }

  verified.sort((a, b) => a.latency - b.latency);

  if (verified.length > 0) {
    fs.mkdirSync(path.dirname(CACHE_FILE), { recursive: true });
    fs.writeFileSync(
      CACHE_FILE,
      JSON.stringify({ timestamp: Date.now(), proxies: verified }, null, 2),
      'utf8'
    );
    log(`saved ${verified.length} verified fast proxies to cache`);
  }

  return verified;
}

/**
 * Pre-flight health check on a ProxyPool before minting begins.
 * Removes any proxies that are dead or exceed maxLatencyMs.
 * Auto-refills the pool if it drops below minHealthy.
 */
async function preflightHealthCheck(proxyPool, { maxLatency = 3500, minHealthy = 6, log = () => {}, isUserProvided = false } = {}) {
  if (!proxyPool || proxyPool.isEmpty()) return [];

  log(`running pre-flight health check on ${proxyPool.length} proxy(ies) (max latency < ${maxLatency}ms)...`);
  const currentProxies = [...proxyPool.proxies];
  const deadList = [];

  await Promise.all(
    currentProxies.map(async (p) => {
      const alive = await validateMailtmProxy(p, maxLatency);
      if (!alive) {
        deadList.push(p);
      } else {
        p.latency = alive.latency;
      }
    })
  );

  if (isUserProvided) {
    if (deadList.length > 0) {
      proxyPool.proxies = proxyPool.proxies.filter(
        (p) => !deadList.some((d) => d.host === p.host && d.port === p.port && d.username === p.username)
      );
      log(`pre-flight check complete: ${proxyPool.length} alive & fast (< ${maxLatency}ms), ${deadList.length} excluded from session`);
    } else {
      log(`pre-flight check complete: all ${proxyPool.length} proxies alive & fast (< ${maxLatency}ms)`);
    }
    // Do not fall back to web scraping if user provided their own proxy list
    return proxyPool.proxies;
  }

  for (const dead of deadList) {
    proxyPool.removeProxy(dead, `preflight test failed / latency > ${maxLatency}ms`);
  }

  log(`pre-flight check complete: ${proxyPool.length} alive & fast (< ${maxLatency}ms), ${deadList.length} removed`);

  // If pool dropped below healthy threshold, replenish with fresh scrape
  if (proxyPool.length < minHealthy) {
    log(`active pool below ${minHealthy} proxies (${proxyPool.length} left) — scraping fresh pool...`);
    const fresh = await scrapeAndVerifyMailtmProxies({
      targetCount: minHealthy + 6,
      maxLatency,
      forceRefresh: true,
      log,
    });
    for (const f of fresh) {
      if (!proxyPool.proxies.some((p) => p.host === f.host && p.port === f.port)) {
        proxyPool.proxies.push(f);
      }
    }
  }

  return proxyPool.proxies;
}

module.exports = {
  validateMailtmProxy,
  scrapeCandidates,
  scrapeAndVerifyMailtmProxies,
  preflightHealthCheck,
  CACHE_FILE,
};
