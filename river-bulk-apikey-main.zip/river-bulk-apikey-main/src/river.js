'use strict';

/**
 * River AI Console automation primitives.
 *
 * Sign-up / e-mail verification run on WorkOS AuthKit's hosted flow
 * (login.console.river.ai) which is protected by Cloudflare Turnstile +
 * WorkOS Radar. Those pages are deliberately hostile to pure HTTP clients,
 * so accounts are created by driving the real UI in a (cloud) browser over CDP.
 *
 * After e-mail verification the console exchanges the OAuth code and starts
 * calling its own API with an `Authorization: Bearer <workos access token>`
 * header. That token is short-lived and never written to web storage, so the
 * toolkit captures it from the first authenticated request via CDP network
 * events, then uses it out-of-band against the console REST API:
 *
 *   POST   https://console.river.ai/api/keys   -> mint an API key
 *   GET    https://console.river.ai/api/keys   -> list API keys
 *   GET    https://console.river.ai/api/me     -> account identity
 *
 * River inference (https://api.river.ai/v1) is OpenAI-compatible.
 */

const http = require('http');
const https = require('https');
const { URL } = require('url');
const { CDP } = require('./cdp');

const HOST = 'https://console.river.ai';
const LOGIN_HOST = 'https://login.console.river.ai';
const API_HOST = 'https://api.river.ai';
const CLIENT_ID = 'client_01M0TG5W3GBNMFS87K40PYHM98';
const REDIRECT_URI = `${HOST}/auth/callback`;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function randomPassword(len = 16) {
  const lower = 'abcdefghijkmnpqrstuvwxyz';
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const digit = '23456789';
  const sym = '!@#$%^&*';
  const pick = (s) => s[Math.floor(Math.random() * s.length)];
  let p = pick(upper) + pick(lower) + pick(digit) + pick(sym);
  const all = lower + upper + digit + sym;
  while (p.length < len) p += pick(all);
  return p;
}

function httpJson(method, url, { headers = {}, body, timeoutMs = 30000 } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const data = body ? (typeof body === 'string' ? body : JSON.stringify(body)) : null;
    const req = lib.request(
      {
        method,
        hostname: u.hostname,
        port: u.port || (u.protocol === 'https:' ? 443 : 80),
        path: u.pathname + u.search,
        headers: Object.assign(
          {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',
            Accept: 'application/json',
          },
          data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {},
          headers
        ),
      },
      (res) => {
        let chunks = '';
        res.on('data', (c) => (chunks += c));
        res.on('end', () => {
          let parsed = null;
          try {
            parsed = chunks ? JSON.parse(chunks) : null;
          } catch {
            parsed = chunks;
          }
          resolve({ status: res.statusCode, headers: res.headers, body: parsed });
        });
      }
    );
    req.setTimeout(timeoutMs, () => req.destroy(new Error('HTTP timeout')));
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

/**
 * Drives the hosted AuthKit UI inside one isolated browser context and returns
 * the context's live state. One instance per account.
 */
class RiverBrowser {
  constructor(cdp, { sessionId, log = () => {} } = {}) {
    this.cdp = cdp;
    this.sessionId = sessionId;
    this.log = log;
  }

  async eval(expression) {
    const r = await this.cdp.send(
      'Runtime.evaluate',
      { expression, returnByValue: true, awaitPromise: true },
      this.sessionId
    );
    if (r.exceptionDetails) {
      const ex = r.exceptionDetails.exception;
      throw new Error(`eval failed: ${(ex && (ex.description || ex.value)) || r.exceptionDetails.text}`);
    }
    return r.result.value;
  }

  async goto(url, { waitMs = 0 } = {}) {
    const loaded = this.cdp
      .waitFor('Page.loadEventFired', { timeoutMs: 15000, sessionId: this.sessionId })
      .catch(() => {});
    await this.cdp.send('Page.navigate', { url }, this.sessionId);
    await Promise.race([loaded, sleep(400)]);
    if (waitMs > 0) await sleep(waitMs);
  }

  async waitForTurnstile({ timeoutMs = 8000, pollMs = 100 } = {}) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const state = await this.eval(`(() => {
        const input = document.querySelector('input[name="cf-turnstile-response"]');
        if (!input) return 'none';
        if (input.value && input.value.length > 10) return 'ready';
        try {
          const w = document.querySelector('#turnstile-widget, .cf-turnstile');
          if (w && !w.dataset.clicked) {
            w.dataset.clicked = 'true';
            w.click();
          }
        } catch(_) {}
        return 'pending';
      })()`).catch(() => 'pending');
      if (state === 'none' || state === 'ready') return true;
      await sleep(pollMs);
    }
    return true;
  }

  text() {
    return this.eval('document.body ? document.body.innerText : ""');
  }

  async waitForText(substr, { timeoutMs = 45000, pollMs = 200 } = {}) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const txt = await this.text().catch(() => '');
      if (txt && txt.toLowerCase().includes(substr.toLowerCase())) return true;
      await sleep(pollMs);
    }
    return false;
  }

  currentUrl() {
    return this.eval('location.href');
  }

  async fillSignup({ firstName, lastName, email }) {
    return this.eval(`(() => {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
      function set(name, val){
        const el = document.querySelector('input[name="'+name+'"]');
        if(!el) return false;
        setter.call(el, val);
        el.dispatchEvent(new Event('input',{bubbles:true}));
        el.dispatchEvent(new Event('change',{bubbles:true}));
        return true;
      }
      const ok1 = set('first_name', ${JSON.stringify(firstName)});
      const ok2 = set('last_name', ${JSON.stringify(lastName)});
      const ok3 = set('email', ${JSON.stringify(email)});
      const btn = [...document.querySelectorAll('button')].find(b => /continue|sign ?up/i.test(b.innerText));
      if(btn && !btn.disabled) btn.click();
      const form = document.querySelector('form');
      if(form && form.requestSubmit) form.requestSubmit();
      return { ok1, ok2, ok3, clicked: !!btn };
    })()`);
  }

  async fillPassword(password) {
    return this.eval(`(() => {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
      const el = document.querySelector('input[type="password"]');
      if(!el) return { ok:false, reason:'no password field' };
      setter.call(el, ${JSON.stringify(password)});
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      const btn = [...document.querySelectorAll('button')].find(b => /continue|create account|sign ?up/i.test(b.innerText));
      if(btn && !btn.disabled) btn.click();
      const form = document.querySelector('form');
      if(form && form.requestSubmit) form.requestSubmit();
      return { ok:true, clicked: !!btn };
    })()`);
  }

  async enterOtp(code) {
    const res = await this.eval(`(() => {
      const inputs = [...document.querySelectorAll('input')];
      const visible = inputs.filter(i => i.type !== 'hidden' && i.style.display !== 'none');
      const targetInputs = visible.length > 0 ? visible : inputs;
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      const c = ${JSON.stringify(code)};

      let filled = false;
      let mode = 'none';

      if (targetInputs.length >= 6) {
        mode = 'multi';
        for (let i = 0; i < 6; i++) {
          if (targetInputs[i]) {
            targetInputs[i].focus();
            setter.call(targetInputs[i], c[i] || '');
            targetInputs[i].dispatchEvent(new Event('input', { bubbles: true }));
            targetInputs[i].dispatchEvent(new Event('change', { bubbles: true }));
            targetInputs[i].dispatchEvent(new KeyboardEvent('keyup', { key: c[i] || '', bubbles: true }));
          }
        }
        filled = true;
      } else if (targetInputs.length > 0) {
        mode = 'single';
        const target = targetInputs.find(i => i.getAttribute('autocomplete') === 'one-time-code' || i.name === 'code' || i.getAttribute('data-input-otp')) || targetInputs[0];
        target.focus();
        setter.call(target, c);
        target.dispatchEvent(new Event('input', { bubbles: true }));
        target.dispatchEvent(new Event('change', { bubbles: true }));
        target.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
        filled = true;
      }

      // Also try paste on first input
      try {
        if (targetInputs[0]) {
          targetInputs[0].focus();
          const dt = new DataTransfer();
          dt.setData('text/plain', c);
          targetInputs[0].dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
        }
      } catch(_) {}

      const btn = [...document.querySelectorAll('button')].find(b => /continue|verify|submit|confirm|next/i.test(b.innerText));
      if (btn && !btn.disabled) {
        btn.click();
      }
      const form = document.querySelector('form');
      if (form && form.requestSubmit) {
        try { form.requestSubmit(); } catch(_) {}
      }

      return {
        ok: filled,
        mode,
        inputsCount: targetInputs.length,
        btnFound: !!btn,
        btnText: btn ? btn.innerText.trim() : null,
        btnDisabled: btn ? btn.disabled : null
      };
    })()`);

    // In parallel, also send native keystrokes via CDP Input.insertText
    try {
      await this.eval(`(() => {
        const inp = document.querySelector('input');
        if (inp) inp.focus();
      })()`);
      await this.cdp.send('Input.insertText', { text: code }, this.sessionId).catch(() => {});
    } catch (_) {}

    return res;
  }
}

/**
 * Full single-account provisioning. Creates an isolated browser context,
 * signs up via the hosted AuthKit UI with a mail.tm inbox, verifies e-mail,
 * captures the console access token, and mints an API key.
 *
 * @returns {Promise<{email,password,apiKey,apiKeyId,token,balanceUsd,raw}>}
 */
async function provisionAccount(cdp, mail, opts = {}) {
  const {
    firstName = 'Alex',
    lastName = 'Morgan',
    password = randomPassword(16),
    keyName = opts.keyName || `key-${Math.random().toString(36).slice(2, 8)}`,
    description,
    expiresInDays,
    log = () => {},
    signupTimeoutMs = 60000,
    verifyTimeoutMs = 120000,
  } = opts;

  // Concurrently provision inbox and isolated browser context
  const [acct, ctx] = await Promise.all([
    mail.createAccount(),
    (async () => {
      const browserContextId = await cdp.createBrowserContext();
      const { targetId, sessionId } = await cdp.newPage({ browserContextId });
      await cdp.send('Page.enable', {}, sessionId);
      await cdp.send('Runtime.enable', {}, sessionId);
      await cdp.send('Network.enable', {}, sessionId);
      // Block heavy media, fonts, maps, and tracking telemetry to maximize proxy bandwidth
      await cdp.send('Network.setBlockedURLs', {
        urls: [
          '*.png', '*.jpg', '*.jpeg', '*.gif', '*.webp', '*.mp4', '*.webm', '*.avi',
          '*.woff2', '*.woff', '*.ttf', '*.eot', '*.map',
          '*sentry.io*', '*mixpanel.com*', '*googletagmanager.com*',
          '*google-analytics.com*', '*googleads*', '*doubleclick.net*',
          '*cloudflareinsights.com*', '*segment.com*', '*intercom.io*',
          '*datadoghq.com*'
        ]
      }, sessionId).catch(() => {});
      return { browserContextId, targetId, sessionId };
    })(),
  ]);

  const email = acct.address;
  const userFirst = acct.firstName || firstName;
  const userLast = acct.lastName || lastName;
  const { browserContextId, targetId, sessionId } = ctx;
  log(`inbox ${email}`);

  let token = null;
  let tokenResolver;
  const tokenPromise = new Promise((resolve) => {
    tokenResolver = resolve;
  });

  const off = cdp.on(
    'Network.requestWillBeSent',
    (p) => {
      const a = p.request.headers.Authorization || p.request.headers.authorization;
      if (!token && a && a.startsWith('Bearer ')) {
        token = a.slice(7);
        tokenResolver(token);
      }
    },
    sessionId
  );

  const tStart = Date.now();
  const rb = new RiverBrowser(cdp, { sessionId, log });
  try {
    let tStep = Date.now();
    const url =
      `${LOGIN_HOST}/sign-up?client_id=${CLIENT_ID}` +
      `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}`;
    await rb.goto(url, { waitMs: 0 });

    // Step 1: name + email
    let ok = await rb.waitForText('First name', { timeoutMs: signupTimeoutMs });
    if (!ok) {
      const pageUrl = await rb.currentUrl().catch(() => 'unknown');
      const pageTxt = await rb.text().catch(() => '');
      throw new Error(`sign-up form did not load (url: ${pageUrl}, page: "${pageTxt.slice(0, 100).replace(/\n/g, ' ')}")`);
    }
    await rb.waitForTurnstile();
    log(`form load + turnstile: ${((Date.now() - tStep) / 1000).toFixed(1)}s`);

    // Step 2: password
    tStep = Date.now();
    await rb.fillSignup({ firstName: userFirst, lastName: userLast, email });
    await rb.waitForText('Password', { timeoutMs: signupTimeoutMs });
    log(`name submit -> password screen: ${((Date.now() - tStep) / 1000).toFixed(1)}s`);

    // Step 3: e-mail verification code
    tStep = Date.now();
    await rb.waitForTurnstile();
    const pwRes = await rb.fillPassword(password);
    const atOtp = await rb.waitForText('Verify your email', { timeoutMs: signupTimeoutMs });
    if (!atOtp) {
      const pageTxt = await rb.text().catch(() => '');
      const pageUrl = await rb.currentUrl().catch(() => '');
      throw new Error(`email verification screen did not appear (pwRes: ${JSON.stringify(pwRes)}, url: ${pageUrl}, text: "${pageTxt.slice(0, 300).replace(/\n/g, ' ')}")`);
    }
    log(`password submit -> otp screen: ${((Date.now() - tStep) / 1000).toFixed(1)}s`);

    const tMail = Date.now();
    const code = await mail.waitForCode({ subjectIncludes: 'verify', timeoutMs: verifyTimeoutMs });
    log(`code ${code} (mail: ${((Date.now() - tMail) / 1000).toFixed(1)}s)`);

    // Step 4: submit OTP and capture Bearer token from River console
    tStep = Date.now();
    const otpRes = await rb.enterOtp(code);
    log(`otp enter (${otpRes ? otpRes.mode : 'unknown'}): ${JSON.stringify(otpRes)}`);

    const deadline = Date.now() + 45000;
    while (!token && Date.now() < deadline) {
      if (token) break;

      // Check localStorage/sessionStorage for access token
      const storageToken = await rb.eval(`(() => {
        try {
          for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            const v = localStorage.getItem(k);
            if (typeof v === 'string' && (v.includes('eyJ') || k.toLowerCase().includes('token'))) {
              const m = v.match(/eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/);
              if (m) return m[0];
            }
          }
          for (let i = 0; i < sessionStorage.length; i++) {
            const k = sessionStorage.key(i);
            const v = sessionStorage.getItem(k);
            if (typeof v === 'string' && (v.includes('eyJ') || k.toLowerCase().includes('token'))) {
              const m = v.match(/eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/);
              if (m) return m[0];
            }
          }
        } catch(_) {}
        return null;
      })()`).catch(() => null);

      if (storageToken) {
        token = storageToken;
        break;
      }

      // Re-trigger submit/continue button if present and enabled
      await rb.eval(`(() => {
        const btn = [...document.querySelectorAll('button')].find(b => /continue|verify|submit|confirm|next/i.test(b.innerText));
        if (btn && !btn.disabled) btn.click();
      })()`).catch(() => {});

      await sleep(1000);
    }

    if (!token) {
      const pageTxt = await rb.text().catch(() => '');
      const pageUrl = await rb.currentUrl().catch(() => '');
      throw new Error(`did not capture console access token (url: ${pageUrl}, text: "${pageTxt.slice(0, 300).replace(/\n/g, ' ')}")`);
    }
    log(`otp submit -> token captured: ${((Date.now() - tStep) / 1000).toFixed(1)}s`);
  } finally {
    off();
    // Instantly terminate browser network transfer the second token is captured
    await cdp.send('Page.stopLoading', {}, sessionId).catch(() => {});
    await cdp.closePage(targetId).catch(() => {});
    await cdp.disposeBrowserContext(browserContextId).catch(() => {});
  }

  let balanceUsd = null;
  let key = null;
  const [keyRes, billingRes] = await Promise.all([
    createApiKey(token, { name: keyName, description, expiresInDays }),
    httpJson('GET', `${HOST}/api/billing/account`, { headers: { Authorization: `Bearer ${token}` } }),
  ]);
  key = keyRes;
  balanceUsd = billingRes.body && billingRes.body.balance_usd != null ? billingRes.body.balance_usd : null;

  return {
    email,
    password,
    firstName: userFirst,
    lastName: userLast,
    apiKey: key ? key.key : null,
    apiKeyId: key ? key.id : null,
    keyName,
    token,
    balanceUsd,
    raw: key,
  };
}

async function createApiKey(token, { name, description, expiresInDays, teamId } = {}) {
  const headers = { Authorization: `Bearer ${token}` };
  if (teamId) headers['X-River-Team'] = teamId;
  const body = { name };
  if (description) body.description = description;
  if (expiresInDays) body.expires_in_days = expiresInDays;
  const res = await httpJson('POST', `${HOST}/api/keys`, { headers, body });
  if (res.status !== 200 && res.status !== 201) {
    throw new Error(`createApiKey failed (${res.status}): ${JSON.stringify(res.body)}`);
  }
  return res.body;
}

async function listApiKeys(token, { teamId } = {}) {
  const headers = { Authorization: `Bearer ${token}` };
  if (teamId) headers['X-River-Team'] = teamId;
  const res = await httpJson('GET', `${HOST}/api/keys`, { headers });
  if (res.status !== 200) throw new Error(`listApiKeys failed (${res.status})`);
  return res.body;
}

async function whoami(token) {
  const res = await httpJson('GET', `${HOST}/api/me`, { headers: { Authorization: `Bearer ${token}` } });
  return res.body;
}

async function listModels(apiKey) {
  const res = await httpJson('GET', `${API_HOST}/v1/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
  return res.body;
}

module.exports = {
  HOST,
  LOGIN_HOST,
  API_HOST,
  CLIENT_ID,
  REDIRECT_URI,
  RiverBrowser,
  provisionAccount,
  createApiKey,
  listApiKeys,
  whoami,
  listModels,
  httpJson,
  randomPassword,
  sleep,
  CDP,
};
