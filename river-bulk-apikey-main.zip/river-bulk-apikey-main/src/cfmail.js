'use strict';

/**
 * Cloudflare Email Routing + KV Inbox Client for sondev.my.id
 *
 * Interacts with the hermes-inbox worker:
 * - Generates unique @sondev.my.id addresses.
 * - Polls Cloudflare KV (namespace hermes-inbox) for inbound messages.
 * - Reads pre-extracted OTP codes directly from the worker payload.
 */

class CFMail {
  constructor(opts = {}) {
    this.accountId = opts.accountId || process.env.CF_ACCOUNT_ID || '37caafce41ba80b97f4e4807325aa07b';
    this.namespaceId = opts.namespaceId || process.env.CF_KV_NAMESPACE_ID || '0e072a2abd5d40e89f4bd008f7715536';
    this.token = opts.token || process.env.CF_API_TOKEN || 'cfat_9MHp4qnguNbZncQqW2orccXehK8xPBP5NIAKhBQD1ce25137';
    this.domain = opts.domain || process.env.CF_DOMAIN || 'sondev.my.id';
    this.address = null;
    this.localPart = null;
  }

  async createAccount() {
    const rand = 'rv-' + Math.random().toString(36).slice(2, 10);
    this.localPart = rand.toLowerCase();
    this.address = `${this.localPart}@${this.domain}`;
    return { address: this.address, token: null };
  }

  async waitForCode({ timeoutMs = 60000, pollMs = 600 } = {}) {
    const deadline = Date.now() + timeoutMs;
    const base = `https://api.cloudflare.com/client/v4/accounts/${this.accountId}/storage/kv/namespaces/${this.namespaceId}/values`;
    const headers = { Authorization: `Bearer ${this.token}` };

    while (Date.now() < deadline) {
      try {
        const latestRes = await fetch(`${base}/latest/${this.localPart}`, { headers });
        if (latestRes.ok) {
          const msgKey = await latestRes.text();
          if (msgKey && msgKey.startsWith('msg/')) {
            const msgRes = await fetch(`${base}/${msgKey}`, { headers });
            if (msgRes.ok) {
              const data = await msgRes.json();
              if (data.code) return String(data.code);
              const hay = `${data.subject || ''} ${data.snippet || ''} ${data.raw || ''}`;
              const match = hay.match(/\b(\d{6})\b/);
              if (match) return match[1];
            }
          }
        }
      } catch {
        /* ignore transient network errors */
      }
      await new Promise((r) => setTimeout(r, pollMs));
    }
    throw new Error(`Timed out waiting for verification code on ${this.address}`);
  }
}

module.exports = { CFMail };
