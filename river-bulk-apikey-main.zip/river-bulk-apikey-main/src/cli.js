#!/usr/bin/env node
'use strict';

/**
 * river-bulk — bulk create River AI (console.river.ai) accounts with an
 * auto-generated API key each, then export the results.
 *
 * Usage:
 *   node src/cli.js --count 3
 *   node src/cli.js --count 10 --concurrency 2 --out accounts.json
 *   node src/cli.js --cookies "solar_session=..."          # advanced
 *
 * Environment:
 *   BU_CDP_WS     Browser Use cloud CDP WebSocket URL (recommended)
 *   CDP_WS        Generic wss:// or ws:// CDP endpoint
 *   CDP_URL       http(s)://host:port used to resolve /json/version
 *
 * Zero dependencies. Node.js >= 18 (global fetch not required).
 */

const fs = require('fs');
const path = require('path');
const { CDP, provisionAccount } = require('./river');
const { MailTM } = require('./mailtm');
const { CFMail } = require('./cfmail');
const { loadProxies, parseProxy, ProxyPool } = require('./proxy');

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) args[key] = true;
      else {
        args[key] = next;
        i++;
      }
    } else args._.push(a);
  }
  return args;
}

function banner() {
  process.stderr.write(
    '\n' +
      '  \x1b[38;5;39m╭──────────────────────────────────────────────╮\x1b[0m\n' +
      '  \x1b[38;5;39m│\x1b[0m  \x1b[1m🌊 river-bulk\x1b[0m  ·  bulk River AI API-key minter   \x1b[38;5;39m│\x1b[0m\n' +
      '  \x1b[38;5;39m╰──────────────────────────────────────────────╯\x1b[0m\n\n'
  );
}

async function createBrowserUseSession(apiKey, { proxyCountryCode = 'us', noProxy = false, customProxy = null } = {}) {
  process.stderr.write('  [browser-use] creating cloud browser instance...\n');
  const payload = {};
  if (noProxy) {
    payload.proxyCountryCode = null;
    process.stderr.write('  [browser-use] proxy: disabled ($0 bandwidth cost)\n');
  } else if (customProxy) {
    payload.customProxy = customProxy;
    process.stderr.write(`  [browser-use] proxy: custom external (${customProxy.host}:${customProxy.port}) ($0 bandwidth fee)\n`);
  } else {
    payload.proxyCountryCode = proxyCountryCode || 'us';
    process.stderr.write(`  [browser-use] proxy: managed residential (${payload.proxyCountryCode})\n`);
  }

  const res = await fetch('https://api.browser-use.com/api/v4/browsers', {
    method: 'POST',
    headers: {
      'X-Browser-Use-API-Key': apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Browser Use create session failed (${res.status}): ${err}`);
  }
  const data = await res.json();
  const vRes = await fetch(`${data.cdpUrl}/json/version`);
  if (!vRes.ok) {
    throw new Error(`Failed to fetch /json/version from Browser Use CDP (${vRes.status})`);
  }
  const vData = await vRes.json();
  return {
    id: data.id,
    wsUrl: vData.webSocketDebuggerUrl,
    liveUrl: data.liveUrl,
  };
}

async function stopBrowserUseSession(apiKey, sessionId) {
  try {
    process.stderr.write('  [browser-use] stopping cloud browser instance...\n');
    await fetch(`https://api.browser-use.com/api/v4/browsers/${sessionId}`, {
      method: 'PATCH',
      headers: {
        'X-Browser-Use-API-Key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'stop' }),
    });
  } catch (err) {
    process.stderr.write(`  [browser-use] warning: failed to stop session ${sessionId}: ${err.message}\n`);
  }
}

async function resolveWs() {
  if (process.env.BU_CDP_WS) return process.env.BU_CDP_WS;
  if (process.env.CDP_WS) return process.env.CDP_WS;
  if (process.env.CDP_URL) {
    const base = process.env.CDP_URL.replace(/\/$/, '');
    const res = await fetch(`${base}/json/version`);
    const j = await res.json();
    return j.webSocketDebuggerUrl;
  }
  throw new Error('No CDP endpoint. Set BU_API_KEY, BU_CDP_WS, CDP_WS, or CDP_URL.');
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let idx = 0;
  let active = 0;
  let aborted = false;

  return new Promise((resolve) => {
    const next = () => {
      if (aborted || (idx >= items.length && active === 0)) return resolve(results);
      while (!aborted && active < limit && idx < items.length) {
        const i = idx++;
        active++;
        Promise.resolve(worker(items[i], i))
          .then((r) => (results[i] = r))
          .catch((e) => {
            results[i] = { error: e.message };
            if (/cdp timeout|websocket|closed|not connected|econnreset/i.test(e.message)) {
              if (!aborted) {
                aborted = true;
                process.stderr.write(`\n  \x1b[33m[warn] Browser connection lost. Stopping queue gracefully.\x1b[0m\n`);
              }
            }
          })
          .finally(() => {
            active--;
            next();
          });
      }
    };
    next();
  });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || args.h) return usage();

  const count = parseInt(args.count || args.n || '1', 10);
  const concurrency = Math.max(1, parseInt(args.concurrency || args.c || '1', 10));
  const outPath = args.out || 'outputs/river-accounts.json';
  const csvPath = args.csv || outPath.replace(/\.json$/, '.csv');
  const keyPrefix = args['key-prefix'] || 'river-bulk';
  const quiet = !!args.quiet;
  const scrapflyKey = args.scrapfly || args['scrapfly-key'] || process.env.SCRAPFLY_API_KEY;
  const buApiKey = args['bu-api-key'] || process.env.BU_API_KEY;

  banner();

  let buSession = null;
  let cdp = null;

  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  if (!fs.existsSync(csvPath)) {
    fs.writeFileSync(csvPath, 'status,email,password,first_name,last_name,api_key,key_name,balance_usd,error\n');
  }

  try {
    const proxyArg = args.proxy;
    const proxyFile = args['proxy-file'] || (fs.existsSync('proxy.txt') ? 'proxy.txt' : null);
    let proxyList = [];
    if (proxyArg) {
      const p = parseProxy(proxyArg);
      if (p) proxyList.push(p);
    } else if (proxyFile && fs.existsSync(proxyFile)) {
      proxyList = loadProxies(proxyFile);
    }
    const proxyPool = new ProxyPool(proxyList, proxyFile);
    if (!proxyPool.isEmpty()) {
      process.stderr.write(`  [proxy] loaded ${proxyPool.length} custom proxy(ies)${proxyFile ? ' from ' + proxyFile : ''}\n`);
      process.stderr.write(`  [proxy] testing proxy connectivity & bandwidth before launch...\n`);
      await proxyPool.filterAlive('login.console.river.ai:443', 4500);
      if (proxyPool.isEmpty()) {
        process.stderr.write(`  \x1b[33m[proxy] ⚠ all custom proxies are exhausted! falling back to Browser Use managed proxy.\x1b[0m\n`);
      } else {
        process.stderr.write(`  \x1b[32m[proxy] ✔ verified ${proxyPool.length} active custom proxy(ies) ready for browser\x1b[0m\n`);
      }
    }

    let wsUrl;
    if (scrapflyKey && !process.env.CDP_WS && !process.env.BU_CDP_WS) {
      wsUrl = `wss://browser.scrapfly.io?api_key=${encodeURIComponent(scrapflyKey)}&os=windows&solve_captcha=true&proxy_pool=public_residential_pool`;
      process.stderr.write('  [scrapfly] using Scrapfly Cloud Browser (residential proxy + auto Turnstile)\n');
    } else if (buApiKey && !process.env.BU_CDP_WS && !process.env.CDP_WS && !process.env.CDP_URL) {
      const customProxy = !args['no-proxy'] && !proxyPool.isEmpty()
        ? proxyPool.toBrowserUsePayload(proxyPool.getNext())
        : null;
      buSession = await createBrowserUseSession(buApiKey, {
        proxyCountryCode: args['proxy-country'] || process.env.BU_PROXY_COUNTRY || 'us',
        noProxy: !!(args['no-proxy'] || process.env.BU_NO_PROXY),
        customProxy,
      });
      wsUrl = buSession.wsUrl;
      if (buSession.liveUrl) {
        process.stderr.write(`  [browser-use] session ${buSession.id}\n`);
        process.stderr.write(`  [browser-use] live view: ${buSession.liveUrl}\n`);
      }
    } else {
      wsUrl = await resolveWs();
    }

    cdp = new CDP(wsUrl, {});
    await cdp.connect();
    await cdp.attachToPage();
    console.log(`connected to browser · minting ${count} account(s), concurrency ${concurrency}`);

    const forceScrape = !!(args['scrape-mailtm'] || args['scraped-proxy'] || args['scrape-proxy']);
    const defaultMaxLatency = forceScrape || proxyPool.isEmpty() ? '2000' : '3500';
    const useCF = !args['use-mailtm'] && !args.mailtm;
    const cfToken = args['cf-token'] || process.env.CF_API_TOKEN || 'cfat_9MHp4qnguNbZncQqW2orccXehK8xPBP5NIAKhBQD1ce25137';
    let mailtmDomain = null;
    let activeMailPool = proxyPool;
    if (useCF) {
      console.log(`inbox provider · Cloudflare Email Routing (@sondev.my.id)`);
    } else {
      const { scrapeAndVerifyMailtmProxies, preflightHealthCheck } = require('./scraper-proxy');
      if (forceScrape || proxyPool.isEmpty()) {
        const scraped = await scrapeAndVerifyMailtmProxies({
          targetCount: Math.max(30, Math.min(count, 60)),
          maxLatency,
          log: (m) => !quiet && process.stderr.write(`  [mailtm-proxy] ${m}\n`),
          forceRefresh: !!args['refresh-proxies'],
        });
        if (scraped && scraped.length > 0) {
          activeMailPool = new ProxyPool(scraped, null);
        }
      } else if (!activeMailPool.isEmpty()) {
        // Pre-flight health check on user-provided pool before minting starts
        await preflightHealthCheck(activeMailPool, {
          maxLatency,
          minHealthy: Math.max(4, concurrency * 2),
          log: (m) => !quiet && process.stderr.write(`  [mailtm-proxy] ${m}\n`),
          isUserProvided: true,
        });
      }

      if (!activeMailPool.isEmpty()) {
        const pInit = activeMailPool.getNext();
        MailTM.setGlobalProxy(pInit, (failedProxy, reason) => {
          if (activeMailPool === proxyPool && proxyPool.filePath) {
            activeMailPool.proxies = activeMailPool.proxies.filter(
              (p) => !(p.host === failedProxy.host && p.port === failedProxy.port && p.username === failedProxy.username)
            );
          } else {
            activeMailPool.removeProxy(failedProxy, reason);
          }
        });
        process.stderr.write(`  [mail.tm] routed through verified fast proxy (${pInit.host}:${pInit.port} · ${pInit.latency || '<3500'}ms)\n`);
      }
      const mailInit = new MailTM({ pool: activeMailPool });
      mailtmDomain = await mailInit.getDomain();
      console.log(`inbox provider · mail.tm (@${mailtmDomain}) [fast delivery]`);
    }

    const jobs = Array.from({ length: count }, (_, i) => i);

    const results = await mapLimit(jobs, concurrency, async (i) => {
      const tag = `[${i + 1}/${count}]`;
      const log = (m) => !quiet && process.stderr.write(`  ${tag} ${m}\n`);
      log('starting');
      if (concurrency > 1 && i < concurrency && i > 0) {
        await new Promise((r) => setTimeout(r, i * 800));
      }
      const t0 = Date.now();
      const workerProxy = !activeMailPool.isEmpty() ? activeMailPool.getNext() : null;
      const workerMail = useCF
        ? new CFMail({ token: cfToken })
        : new MailTM({
            domain: mailtmDomain,
            pool: activeMailPool,
            proxy: workerProxy,
            onExhausted: (failedProxy, reason) => {
              if (activeMailPool === proxyPool && proxyPool.filePath) {
                activeMailPool.proxies = activeMailPool.proxies.filter(
                  (p) => !(p.host === failedProxy.host && p.port === failedProxy.port && p.username === failedProxy.username)
                );
              } else {
                activeMailPool.removeProxy(failedProxy, reason);
              }
            },
          });
      try {
        const r = await provisionAccount(cdp, workerMail, {
          keyName: `${keyPrefix}-${i + 1}`,
          log,
        });
        log(`✔ ${r.email} · key ${r.apiKey} · $${r.balanceUsd} · ${((Date.now() - t0) / 1000).toFixed(1)}s`);
        // Immediately save valid account to CSV
        const csvLine = [
          'ok',
          r.email,
          r.password,
          r.firstName,
          r.lastName,
          r.apiKey,
          r.keyName,
          r.balanceUsd,
          '',
        ].join(',') + '\n';
        fs.appendFileSync(csvPath, csvLine);
        return r;
      } catch (err) {
        log(`\x1b[31m✖ failed:\x1b[0m ${err.message}`);
        throw err;
      }
    });

    const ok = results.filter((r) => r && r.apiKey);
    const failed = results.filter((r) => !r || !r.apiKey);

    const payload = {
      generated_at: new Date().toISOString(),
      total: count,
      succeeded: ok.length,
      failed: failed.length,
      accounts: results.filter(Boolean).map((r) => ({
        status: r && r.apiKey ? 'ok' : 'error',
        email: r && r.email,
        password: r && r.password,
        firstName: r && r.firstName,
        lastName: r && r.lastName,
        apiKey: r && r.apiKey,
        apiKeyId: r && r.apiKeyId,
        keyName: r && r.keyName,
        balanceUsd: r && r.balanceUsd,
        error: r && r.error,
      })),
    };
    fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));

    console.log(`\n  done · ${ok.length}/${count} succeeded`);
    console.log(`  json → ${outPath}`);
    console.log(`  csv  → ${csvPath}\n`);
  } finally {
    if (cdp) cdp.close();
    if (buSession && buApiKey) {
      await stopBrowserUseSession(buApiKey, buSession.id);
    }
  }
}

function usage() {
  console.log(`
river-bulk — bulk create River AI accounts + API keys

Options:
  -n, --count <n>          number of accounts to create            [1]
  -c, --concurrency <n>    parallel accounts (use 1 for one browser) [1]
      --out <file>         JSON output path           [outputs/river-accounts.json]
      --csv <file>         CSV output path (defaults beside --out)
      --key-prefix <name>  API key name prefix                [river-bulk]
      --bu-api-key <key>   Browser Use API key (auto spawns & cleans up browser)
      --proxy-country <code> Proxy country code for Browser Use [us]
      --proxy <url>        single proxy (e.g. host:port or user:pass@host:port)
      --proxy-file <file>  custom proxy list file (defaults to proxy.txt if present)
      --no-proxy           disable residential proxy on Browser Use ($0 bandwidth cost)
      --scrape-mailtm      auto-scrape & pre-verify fresh, fast proxies for mail.tm
      --refresh-proxies    force fresh proxy scraping (bypass local cache)
      --max-latency <ms>   maximum latency cutoff for proxies [2000 for scrape, 3500 for custom]
      --mailtm             Use mail.tm disposable inboxes (Default - instant delivery)
      --cf                 Use Cloudflare Email Routing (@sondev.my.id)
      --cf-token <token>   Cloudflare API token (for @sondev.my.id)
      --quiet              suppress per-account progress
  -h, --help               show this help

Environment:
  BU_API_KEY                     Browser Use API key (e.g. bu_...)
  CF_API_TOKEN                   Cloudflare API token (defaults to He's sondev.my.id token)
  BU_CDP_WS / CDP_WS / CDP_URL   CDP endpoint of the browser to drive

Examples:
  # Default (Browser Use + mail.tm):
  BU_API_KEY="bu_..." node src/cli.js --count 10 --concurrency 2

  # Using custom proxy.txt for Browser Use + scraped fast proxies for mail.tm:
  BU_API_KEY="bu_..." node src/cli.js --count 50 --concurrency 4 --scrape-mailtm

  # Using Cloudflare Email Routing (@sondev.my.id):
  BU_API_KEY="bu_..." node src/cli.js --count 10 --concurrency 2 --cf
`);
}

main().catch((e) => {
  console.error('\x1b[31m[fatal]\x1b[0m ' + e.message);
  process.exit(1);
});
