'use strict';

const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const https = require('https');
const tls = require('tls');

/**
 * Robust proxy parser supporting multiple formats:
 *   1. geolocation://user:pass@host:port:Country
 *   2. http(s)://user:pass@host:port
 *   3. socks5://user:pass@host:port
 *   4. socks4://host:port
 *   5. user:pass@host:port
 *   6. host:port:user:pass
 *   7. host:port
 */
function parseProxy(line) {
  if (!line || typeof line !== 'string') return null;
  let str = line.trim();
  if (!str || str.startsWith('#') || str.startsWith('//')) return null;

  let protocol = 'http';
  let country = null;

  // Strip protocol prefix (e.g. geolocation://, http://, socks5://, socks4://)
  const protoMatch = str.match(/^([a-zA-Z0-9_\-]+):\/\//);
  if (protoMatch) {
    const rawProto = protoMatch[1].toLowerCase();
    protocol = (rawProto === 'socks5' || rawProto === 'socks4') ? rawProto : 'http';
    str = str.slice(protoMatch[0].length);
  }

  // Format with '@': user:pass@host:port[:country]
  if (str.includes('@')) {
    const atIdx = str.lastIndexOf('@');
    const authPart = str.slice(0, atIdx);
    const hostPart = str.slice(atIdx + 1);

    const [username, ...passParts] = authPart.split(':');
    const password = passParts.join(':');

    const parts = hostPart.split(':');
    const host = parts[0];
    const port = parseInt(parts[1], 10);
    if (parts[2]) country = parts.slice(2).join(':');

    if (!host || isNaN(port)) return null;

    return {
      raw: line.trim(),
      protocol,
      host,
      port,
      username: username || null,
      password: password || null,
      country,
      ignoreCertErrors: true,
    };
  }

  // Format: host:port:user:pass
  const colons = str.split(':');
  if (colons.length === 4) {
    const port = parseInt(colons[1], 10);
    if (!isNaN(port)) {
      return {
        raw: line.trim(),
        protocol,
        host: colons[0],
        port,
        username: colons[2],
        password: colons[3],
        country: null,
        ignoreCertErrors: true,
      };
    }
  }

  // Format: user:pass:host:port (rare alternate)
  if (colons.length === 2) {
    const port = parseInt(colons[1], 10);
    if (!isNaN(port)) {
      return {
        raw: line.trim(),
        protocol,
        host: colons[0],
        port,
        username: null,
        password: null,
        country: null,
        ignoreCertErrors: true,
      };
    }
  }

  return null;
}

function loadProxies(filePath = 'proxy.txt') {
  const resolved = path.isAbsolute(filePath) ? filePath : path.resolve(process.cwd(), filePath);
  if (!fs.existsSync(resolved)) return [];

  const content = fs.readFileSync(resolved, 'utf8');
  const lines = content.split(/\r?\n/);
  const proxies = [];

  for (const line of lines) {
    const p = parseProxy(line);
    if (p) proxies.push(p);
  }

  return proxies;
}

class ProxyPool {
  constructor(proxies = [], filePath = null) {
    this.proxies = proxies;
    this.filePath = filePath;
    this.currentIndex = 0;
  }

  get length() {
    return this.proxies.length;
  }

  isEmpty() {
    return this.proxies.length === 0;
  }

  getNext() {
    if (this.proxies.length === 0) return null;
    const p = this.proxies[this.currentIndex % this.proxies.length];
    this.currentIndex++;
    return p;
  }

  getRandom() {
    if (this.proxies.length === 0) return null;
    const idx = Math.floor(Math.random() * this.proxies.length);
    return this.proxies[idx];
  }

  /**
   * Remove a proxy whose bandwidth is exhausted or dead.
   * Rewrites proxy.txt immediately and shifts to the next proxy.
   */
  removeProxy(proxy, reason = 'bandwidth exhausted / connection error') {
    if (!proxy) return null;
    const beforeCount = this.proxies.length;
    this.proxies = this.proxies.filter(
      (p) => !(p.host === proxy.host && p.port === proxy.port) && p.raw !== proxy.raw
    );

    process.stderr.write(
      `\n  \x1b[33m[proxy] ⚠ proxy ${proxy.host}:${proxy.port} exhausted/failed (${reason}). Removed.\x1b[0m\n`
    );

    // Save updated proxy list back to disk so future runs don't use exhausted proxies
    if (this.filePath && fs.existsSync(this.filePath)) {
      try {
        const remainingRaw = this.proxies.map((p) => p.raw).join('\n');
        fs.writeFileSync(this.filePath, remainingRaw ? remainingRaw + '\n' : '', 'utf8');
        process.stderr.write(
          `  \x1b[32m[proxy] ✔ updated ${this.filePath} (${this.proxies.length} proxy(ies) remaining)\x1b[0m\n`
        );
      } catch (err) {
        process.stderr.write(`  [proxy] warning: failed to update ${this.filePath}: ${err.message}\n`);
      }
    }

    if (this.proxies.length === 0) {
      process.stderr.write(`  \x1b[31m[proxy] ✖ all proxies have been exhausted!\x1b[0m\n`);
      return null;
    }

    return this.getNext();
  }

  async filterAlive(targetHost = 'login.console.river.ai:443', timeoutMs = 4000) {
    if (this.isEmpty()) return [];
    const aliveList = [];
    const deadList = [];
    await Promise.all(
      this.proxies.map(async (p) => {
        const res = await testProxyAlive(p, targetHost, timeoutMs);
        if (res.alive) {
          aliveList.push(p);
        } else {
          deadList.push({ proxy: p, reason: res.reason });
        }
      })
    );

    for (const d of deadList) {
      this.removeProxy(d.proxy, d.reason);
    }

    return this.proxies;
  }

  toBrowserUsePayload(proxy) {
    if (!proxy) return null;
    const payload = {
      host: proxy.host,
      port: proxy.port,
      ignoreCertErrors: true,
    };
    if (proxy.username) payload.username = proxy.username;
    if (proxy.password) payload.password = proxy.password;
    return payload;
  }

  toUrl(proxy) {
    if (!proxy) return null;
    const auth = proxy.username && proxy.password
      ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password)}@`
      : '';
    return `${proxy.protocol}://${auth}${proxy.host}:${proxy.port}`;
  }
}

/**
 * Establishes a raw TCP tunnel through a SOCKS5 proxy (RFC 1928).
 */
function connectSocks5Socket({ host, port, targetHost, targetPort = 443, username = null, password = null, timeoutMs = 5000 }) {
  return new Promise((resolve, reject) => {
    let s = null;
    let timer = setTimeout(() => {
      if (s) s.destroy();
      reject(new Error(`SOCKS5 connection timeout (${timeoutMs}ms)`));
    }, timeoutMs);

    s = net.connect({ host, port });
    s.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });

    s.on('connect', () => {
      if (username && password) {
        s.write(Buffer.from([0x05, 0x02, 0x00, 0x02]));
      } else {
        s.write(Buffer.from([0x05, 0x01, 0x00]));
      }
    });

    let state = 'method';
    s.on('data', (chunk) => {
      if (state === 'method') {
        if (chunk.length < 2 || chunk[0] !== 0x05) {
          clearTimeout(timer);
          s.destroy();
          return reject(new Error('Invalid SOCKS5 handshake response'));
        }
        const method = chunk[1];
        if (method === 0x00) {
          state = 'connect';
          sendConnect();
        } else if (method === 0x02 && username && password) {
          state = 'auth';
          const uBuf = Buffer.from(username, 'utf8');
          const pBuf = Buffer.from(password, 'utf8');
          s.write(Buffer.concat([
            Buffer.from([0x01, uBuf.length]),
            uBuf,
            Buffer.from([pBuf.length]),
            pBuf,
          ]));
        } else {
          clearTimeout(timer);
          s.destroy();
          return reject(new Error(`SOCKS5 authentication method 0x${method.toString(16)} unsupported`));
        }
      } else if (state === 'auth') {
        if (chunk.length < 2 || chunk[1] !== 0x00) {
          clearTimeout(timer);
          s.destroy();
          return reject(new Error('SOCKS5 authentication failed'));
        }
        state = 'connect';
        sendConnect();
      } else if (state === 'connect') {
        clearTimeout(timer);
        if (chunk.length < 2 || chunk[0] !== 0x05 || chunk[1] !== 0x00) {
          s.destroy();
          return reject(new Error(`SOCKS5 connect rejected with code ${chunk[1]}`));
        }
        s.removeAllListeners('data');
        s.removeAllListeners('error');
        resolve(s);
      }
    });

    function sendConnect() {
      const hBuf = Buffer.from(targetHost, 'utf8');
      s.write(Buffer.concat([
        Buffer.from([0x05, 0x01, 0x00, 0x03, hBuf.length]),
        hBuf,
        Buffer.from([(targetPort >> 8) & 0xff, targetPort & 0xff]),
      ]));
    }
  });
}

/**
 * Establishes a raw TCP tunnel through a SOCKS4a proxy.
 */
function connectSocks4Socket({ host, port, targetHost, targetPort = 443, username = '', timeoutMs = 5000 }) {
  return new Promise((resolve, reject) => {
    let s = null;
    let timer = setTimeout(() => {
      if (s) s.destroy();
      reject(new Error(`SOCKS4 connection timeout (${timeoutMs}ms)`));
    }, timeoutMs);

    s = net.connect({ host, port });
    s.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });

    s.on('connect', () => {
      const uBuf = Buffer.from((username || '') + '\0', 'utf8');
      const hBuf = Buffer.from(targetHost + '\0', 'utf8');
      s.write(Buffer.concat([
        Buffer.from([0x04, 0x01, (targetPort >> 8) & 0xff, targetPort & 0xff, 0x00, 0x00, 0x00, 0x01]),
        uBuf,
        hBuf,
      ]));
    });

    s.on('data', (chunk) => {
      clearTimeout(timer);
      if (chunk.length < 2 || chunk[1] !== 0x5a) {
        s.destroy();
        return reject(new Error(`SOCKS4 connect rejected with code ${chunk[1] || 'unknown'}`));
      }
      s.removeAllListeners('data');
      s.removeAllListeners('error');
      resolve(s);
    });
  });
}

/**
 * Checks whether an HTTP/SOCKS proxy can tunnel to targetHost.
 * Returns { alive: true/false, statusCode, reason }.
 */
function testProxyAlive(proxy, targetHost = 'login.console.river.ai:443', timeoutMs = 5000) {
  const p = typeof proxy === 'string' ? parseProxy(proxy) : proxy;
  if (!p) return Promise.resolve({ alive: false, reason: 'invalid proxy' });

  const [h, portStr] = targetHost.split(':');
  const port = portStr ? parseInt(portStr, 10) : 443;

  if (p.protocol === 'socks5') {
    return connectSocks5Socket({
      host: p.host,
      port: p.port,
      targetHost: h,
      targetPort: port,
      username: p.username,
      password: p.password,
      timeoutMs,
    })
      .then((s) => {
        s.destroy();
        return { alive: true, statusCode: 200 };
      })
      .catch((err) => ({ alive: false, reason: err.message }));
  }

  if (p.protocol === 'socks4') {
    return connectSocks4Socket({
      host: p.host,
      port: p.port,
      targetHost: h,
      targetPort: port,
      username: p.username,
      timeoutMs,
    })
      .then((s) => {
        s.destroy();
        return { alive: true, statusCode: 200 };
      })
      .catch((err) => ({ alive: false, reason: err.message }));
  }

  // HTTP CONNECT
  return new Promise((resolve) => {
    const headers = { Host: targetHost };
    if (p.username && p.password) {
      headers['Proxy-Authorization'] = 'Basic ' + Buffer.from(`${p.username}:${p.password}`).toString('base64');
    }

    const req = http.request({
      host: p.host,
      port: p.port,
      method: 'CONNECT',
      path: targetHost,
      headers,
      timeout: timeoutMs,
    });

    req.on('connect', (res, socket) => {
      socket.destroy();
      if (res.statusCode === 200) {
        resolve({ alive: true, statusCode: 200 });
      } else {
        resolve({ alive: false, statusCode: res.statusCode, reason: `HTTP ${res.statusCode} ${res.statusMessage}` });
      }
    });

    req.on('error', (err) => resolve({ alive: false, reason: err.message }));
    req.on('timeout', () => {
      req.destroy();
      resolve({ alive: false, reason: 'timeout' });
    });
    req.end();
  });
}

/**
 * Creates a native Node.js https.Agent that tunnels HTTPS requests
 * through an HTTP, SOCKS5, or SOCKS4 proxy (zero dependencies).
 */
function createProxyAgent(proxy, onExhausted = null) {
  if (!proxy) return null;
  const p = typeof proxy === 'string' ? parseProxy(proxy) : proxy;
  if (!p) return null;

  return new https.Agent({
    keepAlive: true,
    createConnection(options, callback) {
      const targetHost = options.host;
      const targetPort = options.port || 443;

      if (p.protocol === 'socks5') {
        connectSocks5Socket({
          host: p.host,
          port: p.port,
          targetHost,
          targetPort,
          username: p.username,
          password: p.password,
          timeoutMs: 15000,
        })
          .then((rawSocket) => {
            const tlsSocket = tls.connect(
              {
                socket: rawSocket,
                servername: targetHost,
                rejectUnauthorized: p.ignoreCertErrors ? false : true,
              },
              () => callback(null, tlsSocket)
            );
            tlsSocket.on('error', (err) => callback(err));
          })
          .catch((err) => {
            if (onExhausted) onExhausted(p, err.message);
            callback(err);
          });
        return;
      }

      if (p.protocol === 'socks4') {
        connectSocks4Socket({
          host: p.host,
          port: p.port,
          targetHost,
          targetPort,
          username: p.username,
          timeoutMs: 15000,
        })
          .then((rawSocket) => {
            const tlsSocket = tls.connect(
              {
                socket: rawSocket,
                servername: targetHost,
                rejectUnauthorized: p.ignoreCertErrors ? false : true,
              },
              () => callback(null, tlsSocket)
            );
            tlsSocket.on('error', (err) => callback(err));
          })
          .catch((err) => {
            if (onExhausted) onExhausted(p, err.message);
            callback(err);
          });
        return;
      }

      // Default: HTTP CONNECT tunnel
      const connectReq = http.request({
        host: p.host,
        port: p.port,
        method: 'CONNECT',
        path: `${targetHost}:${targetPort}`,
        headers: {
          Host: `${targetHost}:${targetPort}`,
          ...(p.username && p.password
            ? { 'Proxy-Authorization': 'Basic ' + Buffer.from(`${p.username}:${p.password}`).toString('base64') }
            : {}),
        },
      });

      connectReq.on('connect', (res, socket) => {
        if (res.statusCode !== 200) {
          socket.destroy();
          const err = new Error(`Proxy CONNECT to ${targetHost} failed (${res.statusCode}): ${res.statusMessage}`);
          const isExhausted = [402, 403, 407, 429, 502, 503, 504].includes(res.statusCode);
          if (isExhausted && onExhausted) {
            onExhausted(p, `HTTP ${res.statusCode} ${res.statusMessage}`);
          }
          return callback(err);
        }
        const tlsSocket = tls.connect(
          {
            socket,
            servername: targetHost,
            rejectUnauthorized: p.ignoreCertErrors ? false : true,
          },
          () => {
            callback(null, tlsSocket);
          }
        );
        tlsSocket.on('error', (err) => callback(err));
      });

      connectReq.on('error', (err) => {
        if (/econnreset|econnrefused|etimedout|socket hang up/i.test(err.message) && onExhausted) {
          onExhausted(p, err.message);
        }
        callback(err);
      });
      connectReq.end();
    },
  });
}

module.exports = {
  parseProxy,
  loadProxies,
  ProxyPool,
  createProxyAgent,
  testProxyAlive,
  connectSocks5Socket,
  connectSocks4Socket,
};
