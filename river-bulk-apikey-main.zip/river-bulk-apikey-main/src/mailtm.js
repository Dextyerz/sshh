'use strict';

/**
 * Minimal mail.tm client (https://docs.mail.tm).
 * Creates disposable inboxes and polls for verification e-mails.
 * Zero dependencies - uses Node's built-in https.
 */

const https = require('https');
const { URL } = require('url');

const API = 'https://api.mail.tm';

let globalProxyAgent = null;

async function request(method, path, { token, body, retries = 3, agent = null } = {}) {
  const reqAgent = agent || globalProxyAgent;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const res = await new Promise((resolve, reject) => {
      const u = new URL(API + path);
      const data = body ? JSON.stringify(body) : null;
      const headers = { Accept: 'application/json' };
      if (data) {
        headers['Content-Type'] = 'application/json';
        headers['Content-Length'] = Buffer.byteLength(data);
      }
      if (token) headers.Authorization = `Bearer ${token}`;
      const reqOpts = {
        method,
        hostname: u.hostname,
        port: 443,
        path: u.pathname + u.search,
        headers,
        timeout: 15000,
      };
      if (reqAgent) reqOpts.agent = reqAgent;
      const req = https.request(reqOpts, (r) => {
        let chunks = '';
        r.on('data', (c) => (chunks += c));
        r.on('end', () => {
          let parsed = null;
          try {
            parsed = chunks ? JSON.parse(chunks) : null;
          } catch {
            parsed = chunks;
          }
          resolve({ status: r.statusCode, headers: r.headers, body: parsed });
        });
      });
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`mail.tm request timeout: ${method} ${path}`));
      });
      if (data) req.write(data);
      req.end();
    });

    if (res.status === 429 && !reqAgent && attempt < retries) {
      const delay = (attempt + 1) * 2500;
      await new Promise((r) => setTimeout(r, delay));
      continue;
    }

    return res;
  }
}

let globalDomainCache = null;

const FIRST_NAMES = [
  'Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Sam', 'Jamie',
  'Logan', 'Chris', 'Avery', 'Dakota', 'Reese', 'Cameron', 'Skyler', 'Lucas',
  'Liam', 'Noah', 'Oliver', 'Mason', 'Ethan', 'Emma', 'Olivia', 'Ava', 'Sophia'
];

const LAST_NAMES = [
  'Stone', 'Wood', 'Ford', 'Brook', 'Field', 'Hart', 'Bell', 'Gray',
  'Cross', 'Fox', 'Ward', 'Hunt', 'Page', 'Cole', 'West', 'Dale',
  'Clark', 'Hill', 'Moore', 'Wright', 'Scott', 'Davis', 'Miller'
];

function generateCleanIdentity() {
  const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  const num = Math.floor(100 + Math.random() * 900);
  const username = `${firstName.toLowerCase()}_${lastName.toLowerCase()}${num}`;
  return { firstName, lastName, username };
}

let creationQueue = Promise.resolve();
const ACCOUNT_CREATE_MIN_GAP_MS = 1400;

class MailTM {
  static setGlobalProxy(proxyOrAgent, onExhausted = null) {
    if (!proxyOrAgent) {
      globalProxyAgent = null;
      return;
    }
    if (proxyOrAgent instanceof https.Agent) {
      globalProxyAgent = proxyOrAgent;
      return;
    }
    const { createProxyAgent } = require('./proxy');
    globalProxyAgent = createProxyAgent(proxyOrAgent, onExhausted);
  }

  constructor({ domain, pool, proxy, agent, onExhausted = null } = {}) {
    this.domain = domain || globalDomainCache || null;
    this.token = null;
    this.pool = pool || null;
    this.proxy = proxy || (this.pool ? this.pool.getNext() : null);
    this.onExhausted = onExhausted;
    this.agent = null;
    this.updateAgent(agent);
  }

  updateAgent(explicitAgent = null) {
    if (explicitAgent) {
      this.agent = explicitAgent;
    } else if (this.proxy) {
      const { createProxyAgent } = require('./proxy');
      this.agent = createProxyAgent(this.proxy, (failedProxy, reason) => {
        if (this.pool) this.pool.removeProxy(failedProxy, reason);
        if (this.onExhausted) this.onExhausted(failedProxy, reason);
      });
    } else {
      this.agent = globalProxyAgent;
    }
  }

  rotateProxy(reason = 'connection failed / proxy dead', permanent = true) {
    if (this.pool && this.proxy) {
      const dead = this.proxy;
      if (permanent) {
        if (this.onExhausted) {
          this.onExhausted(dead, reason);
        } else {
          this.pool.removeProxy(dead, reason);
        }
      }
      this.proxy = this.pool.getNext();
      this.updateAgent();
      return this.proxy;
    }
    return null;
  }

  async _req(method, path, options = {}) {
    const maxAttempts = this.pool ? 10 : 3;
    let lastErr = null;
    for (let i = 0; i < maxAttempts; i++) {
      try {
        const res = await request(method, path, {
          ...options,
          agent: this.agent,
          timeout: 10000,
        });

        if (res.status === 429) {
          // Temporary IP rate limit: rotate to next proxy in pool without deleting
          if (this.pool && this.pool.length > 1) {
            this.rotateProxy('rate limited (429)', false);
            await new Promise((r) => setTimeout(r, 600));
            continue;
          } else {
            const delay = (i + 1) * 2000;
            await new Promise((r) => setTimeout(r, delay));
            continue;
          }
        }

        if (
          res.status === 402 ||
          res.status === 407 ||
          res.status === 502 ||
          res.status === 503 ||
          res.status === 504
        ) {
          throw new Error(`Proxy status error ${res.status}`);
        }
        return res;
      } catch (err) {
        lastErr = err;
        if (this.pool && i < maxAttempts - 1) {
          this.rotateProxy(err.message, true);
          continue;
        }
        throw err;
      }
    }
    throw lastErr;
  }

  async getDomain() {
    if (this.domain) return this.domain;
    if (globalDomainCache) {
      this.domain = globalDomainCache;
      return this.domain;
    }
    const res = await this._req('GET', '/domains');
    const list = res.body['hydra:member'] || res.body;
    const active = (list || []).find((d) => d.isActive) || (list || [])[0];
    if (!active) throw new Error('No active mail.tm domain available');
    this.domain = active.domain;
    globalDomainCache = this.domain;
    return this.domain;
  }

  async createAccount({ address, password, domain } = {}) {
    const run = async () => {
      const d = domain || (await this.getDomain());
      const ident = generateCleanIdentity();
      const addr = address || `${ident.username}@${d}`;
      const pass = password || Math.random().toString(36).slice(2, 14) + 'Aa1!';
      const res = await this._req('POST', '/accounts', { body: { address: addr, password: pass }, retries: 4 });
      if (res.status !== 201 && res.status !== 200) {
        throw new Error(`mail.tm account creation failed (${res.status}): ${JSON.stringify(res.body)}`);
      }
      this.token = await this.login({ address: addr, password: pass });
      // Enforce healthy interval between account creations to stay below mail.tm rate limits
      await new Promise((r) => setTimeout(r, ACCOUNT_CREATE_MIN_GAP_MS));
      return {
        address: addr,
        password: pass,
        token: this.token,
        id: res.body.id,
        firstName: ident.firstName,
        lastName: ident.lastName,
      };
    };

    const next = creationQueue.then(run, run);
    creationQueue = next.catch(() => {});
    return next;
  }

  async login({ address, password }) {
    const res = await this._req('POST', '/token', { body: { address, password } });
    if (res.status !== 200) throw new Error(`mail.tm login failed (${res.status})`);
    this.token = res.body.token;
    return this.token;
  }

  async messages({ address, password } = {}) {
    const token = this.token || (address ? await this.login({ address, password }) : null);
    if (!token) throw new Error('Not authenticated: call createAccount/login or pass address+password');
    const res = await this._req('GET', '/messages', { token });
    if (res.status !== 200) throw new Error(`mail.tm messages failed (${res.status})`);
    return res.body['hydra:member'] || res.body;
  }

  async message(id, { address, password } = {}) {
    const token = this.token || (address ? await this.login({ address, password }) : null);
    const res = await this._req('GET', `/messages/${id}`, { token });
    if (res.status !== 200) throw new Error(`mail.tm message failed (${res.status})`);
    return res.body;
  }

  /**
   * Poll the inbox until a message arrives and contains a 6-digit code.
   * Checks subject/intro snippet first to avoid unnecessary roundtrips.
   */
  async waitForCode({ timeoutMs = 90000, pollMs = 1200, initialDelayMs = 1200, subjectIncludes } = {}) {
    if (initialDelayMs > 0) {
      await new Promise((r) => setTimeout(r, initialDelayMs));
    }
    const deadline = Date.now() + timeoutMs;
    let seen = new Set();
    while (Date.now() < deadline) {
      let msgs = [];
      try {
        msgs = await this.messages();
      } catch {
        await new Promise((r) => setTimeout(r, pollMs));
        continue;
      }
      for (const m of msgs) {
        if (subjectIncludes && !(m.subject || '').toLowerCase().includes(subjectIncludes.toLowerCase())) continue;

        // Fast path: extract OTP code directly from intro/subject if available
        const snippet = `${m.subject || ''} ${m.intro || ''}`;
        const snippetMatch = snippet.match(/\b(\d{6})\b/);
        if (snippetMatch) {
          const ctx = snippet.match(/code[^0-9]{0,40}(\d{6})/i);
          return ctx ? ctx[1] : snippetMatch[1];
        }

        const full = await this.message(m.id);
        const text = `${full.text || ''}\n${Array.isArray(full.html) ? full.html.join(' ') : full.html || ''}`;
        const match = text.match(/\b(\d{6})\b/);
        if (match) {
          // Prefer a code that appears in a "verify" context; else first 6-digit run.
          const ctx = text.match(/code[^0-9]{0,40}(\d{6})/i);
          return ctx ? ctx[1] : match[1];
        }
        seen.add(m.id);
      }
      await new Promise((r) => setTimeout(r, pollMs));
    }
    throw new Error('Timed out waiting for verification e-mail');
  }
}

module.exports = { MailTM, request };
