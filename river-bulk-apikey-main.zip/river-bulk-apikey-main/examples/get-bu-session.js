#!/usr/bin/env node
'use strict';

/**
 * Helper to manage Browser Use Cloud browser sessions via API Key.
 *
 * Usage:
 *   # Create a browser and print CDP WebSocket URL
 *   BU_API_KEY="bu_..." node examples/get-bu-session.js --create
 *
 *   # Stop an active browser session
 *   BU_API_KEY="bu_..." node examples/get-bu-session.js --stop <session-id>
 */

const apiKey = process.env.BU_API_KEY || process.argv.find((a, i, arr) => arr[i - 1] === '--key');

if (!apiKey) {
  console.error('Error: BU_API_KEY environment variable or --key argument is required.');
  process.exit(1);
}

const args = process.argv.slice(2);
const stopIdx = args.indexOf('--stop');
const stopId = stopIdx !== -1 ? args[stopIdx + 1] : null;

async function run() {
  if (stopId) {
    console.log(`Stopping Browser Use session: ${stopId}...`);
    const res = await fetch(`https://api.browser-use.com/api/v4/browsers/${stopId}`, {
      method: 'PATCH',
      headers: {
        'X-Browser-Use-API-Key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action: 'stop' }),
    });
    const data = await res.json();
    console.log('Result:', data);
    return;
  }

  console.log('Creating Browser Use cloud session...');
  const createRes = await fetch('https://api.browser-use.com/api/v4/browsers', {
    method: 'POST',
    headers: {
      'X-Browser-Use-API-Key': apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ proxyCountryCode: 'us' }),
  });

  if (!createRes.ok) {
    throw new Error(`Failed to create browser: ${createRes.status} ${await createRes.text()}`);
  }

  const session = await createRes.json();
  console.log(`Session ID : ${session.id}`);
  console.log(`Live Stream: ${session.liveUrl}`);

  const vRes = await fetch(`${session.cdpUrl}/json/version`);
  if (!vRes.ok) {
    throw new Error(`Failed to resolve /json/version: ${vRes.status}`);
  }
  const vData = await vRes.json();
  const wsUrl = vData.webSocketDebuggerUrl;

  console.log(`\nCDP WebSocket URL:`);
  console.log(wsUrl);
  console.log(`\nTo run river-bulk manually with this browser:`);
  console.log(`export BU_CDP_WS="${wsUrl}"`);
  console.log(`node src/cli.js --count 1`);
  console.log(`\nRemember to stop the session when done:`);
  console.log(`node examples/get-bu-session.js --stop ${session.id}`);
}

run().catch((e) => {
  console.error('[error]', e.message);
  process.exit(1);
});
