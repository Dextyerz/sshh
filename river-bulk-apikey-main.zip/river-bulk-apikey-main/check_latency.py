#!/usr/bin/env python3
"""
Benchmark latency from proxy.txt to api.mail.tm
"""
import json
import ssl
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def parse_line(line):
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    s = line
    if "://" in s:
        s = s.split("://", 1)[1]
    if "@" in s:
        auth, host_part = s.rsplit("@", 1)
        parts = host_part.split(":")
        host = parts[0]
        port = "".join(filter(str.isdigit, parts[1])) if len(parts) > 1 else ""
        if host and port:
            return {
                "raw": line,
                "user": auth.split(":")[0],
                "proxy_url": f"http://{auth}@{host}:{port}",
                "host": host,
                "port": port,
            }
    return None


def check_proxy(idx, p):
    url = p["proxy_url"]
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": url, "https": url}),
        urllib.request.HTTPSHandler(context=ctx),
    )
    t0 = time.time()
    try:
        req = urllib.request.Request(
            "https://api.mail.tm/domains",
            headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"},
        )
        resp = opener.open(req, timeout=10)
        dt = (time.time() - t0) * 1000
        data = json.loads(resp.read().decode("utf-8"))
        domain = data[0]["domain"] if isinstance(data, list) and data else "ok"
        return idx, p["user"], resp.status, dt, f"@{domain}"
    except urllib.error.HTTPError as e:
        dt = (time.time() - t0) * 1000
        return idx, p["user"], e.code, dt, f"HTTP {e.code}"
    except Exception as e:
        dt = (time.time() - t0) * 1000
        err = str(e)
        if "timed out" in err.lower():
            err = "Timeout (>10s)"
        return idx, p["user"], 0, dt, err[:20]


def main():
    proxies = []
    try:
        with open("proxy.txt") as f:
            for line in f:
                p = parse_line(line)
                if p:
                    proxies.append(p)
    except FileNotFoundError:
        print("proxy.txt not found!")
        return

    print(f"Loaded {len(proxies)} proxies from proxy.txt\n")
    print(f"{'#':<4} {'Proxy User':<20} {'Status':<12} {'Latency (ms)':<15} {'Target'}")
    print("-" * 65)

    results = []
    with ThreadPoolExecutor(max_workers=20) as pool:
        futures = [pool.submit(check_proxy, i + 1, p) for i, p in enumerate(proxies)]
        for f in as_completed(futures):
            res = f.result()
            results.append(res)
            idx, user, status, lat, note = res
            status_str = f"HTTP {status}" if status else "FAIL"
            print(f"{idx:<4} {user:<20} {status_str:<12} {lat:>8.1f} ms      {note}")

    results.sort(key=lambda x: x[0])
    ok_results = [r for r in results if r[2] == 200]
    print("=" * 65)
    print(f"Summary: {len(ok_results)} / {len(results)} proxies alive")
    if ok_results:
        lats = [r[3] for r in ok_results]
        print(f"Min latency : {min(lats):.1f} ms")
        print(f"Avg latency : {sum(lats)/len(lats):.1f} ms")
        print(f"Max latency : {max(lats):.1f} ms")


if __name__ == "__main__":
    main()
