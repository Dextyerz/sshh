'use strict';

const http = require('http');
const tls = require('tls');

const countries = [
  { code: 'US', name: 'United States', host: 'geo.floppydata.com', port: 10080, user: 'QVHskw2WmjSDKcYI', pass: 'O8I7xZpNMO5z5iRj' },
  { code: 'GB', name: 'United Kingdom', host: 'geo.floppydata.com', port: 10080, user: 'NDceuXkY6mJzgREL', pass: 'BVvM398Wp6ytUVG1' },
  { code: 'FR', name: 'France', host: 'geo.floppydata.com', port: 10080, user: 'RWyc4tzaPrYDv5fZ', pass: 'BNjKtd1kP3qsar2a' },
  { code: 'CA', name: 'Canada', host: 'geo.floppydata.com', port: 10080, user: 'YDiN7wzp9GBeOXMX', pass: 'ltSI3FqN4K0j7Ub8' },
  { code: 'AU', name: 'Australia', host: 'geo.floppydata.com', port: 10080, user: 'OlQiVnzKeKIFa5HM', pass: 'dhl1vbqTsnmXm3pJ' },
];

function testRiverLatency(proxy, targetHost = 'login.console.river.ai') {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const req = http.request({
      host: proxy.host,
      port: proxy.port,
      method: 'CONNECT',
      path: `${targetHost}:443`,
      headers: {
        'Host': `${targetHost}:443`,
        'Proxy-Authorization': 'Basic ' + Buffer.from(proxy.user + ':' + proxy.pass).toString('base64'),
      },
      timeout: 10000,
    });

    req.on('connect', (res, socket) => {
      if (res.statusCode !== 200) {
        socket.destroy();
        return resolve({ success: false, status: res.statusCode });
      }
      const tlsSocket = tls.connect({ socket, servername: targetHost, rejectUnauthorized: false }, () => {
        tlsSocket.write(`GET / HTTP/1.1\r\nHost: ${targetHost}\r\nConnection: close\r\nAccept: text/html\r\n\r\n`);
      });
      let data = '';
      tlsSocket.on('data', c => data += c);
      tlsSocket.on('end', () => {
        const lat = Date.now() - t0;
        const ok = data.includes('HTTP/1.1 200') || data.includes('HTTP/1.1 30') || data.includes('River');
        resolve({ success: ok || data.length > 0, latency: lat });
      });
      tlsSocket.on('error', () => resolve({ success: false }));
    });
    req.on('error', () => resolve({ success: false }));
    req.on('timeout', () => {
      req.destroy();
      resolve({ success: false, timeout: true });
    });
    req.end();
  });
}

(async () => {
  console.log('Benchmarking latency from each country proxy to River AI (login.console.river.ai)...\n');
  const results = [];
  for (const c of countries) {
    const lats = [];
    for (let i = 0; i < 3; i++) {
      const res = await testRiverLatency(c);
      if (res.success) lats.push(res.latency);
      await new Promise(r => setTimeout(r, 300));
    }
    const avg = lats.length ? Math.round(lats.reduce((a, b) => a + b, 0) / lats.length) : null;
    const min = lats.length ? Math.min(...lats) : null;
    results.push({ ...c, lats, avg, min });
    console.log(`[${c.code}] ${c.name.padEnd(15)} : min = ${String(min).padStart(4)}ms | avg = ${String(avg).padStart(4)}ms | runs: ${lats.join(', ')}ms`);
  }

  results.sort((a, b) => (a.avg || 99999) - (b.avg || 99999));
  console.log('\n=============================================');
  console.log('🏆 RANKING LATENCY TERENDAH KE RIVER AI');
  console.log('=============================================');
  results.forEach((r, idx) => {
    console.log(`${idx + 1}. [${r.code}] ${r.name.padEnd(15)} -> Avg: ${String(r.avg).padStart(4)}ms | Min: ${String(r.min).padStart(4)}ms`);
  });
})();
